from django.apps import AppConfig


class YbasApiConfig(AppConfig):
    name = 'api'
